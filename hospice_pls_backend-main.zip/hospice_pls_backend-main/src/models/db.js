// src/models/db.js

import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from './schema.js';

// Load environment variables (e.g., DTABAS_URL)
// In a real Fastify app, you'd use a dedicated config solution like 'dotenv'
// const connectionString = process.env.DATABASE_URL;
const connectionString = 'postgres://user:password@host:port/database'; // Placeholder

// Create the Postgres clien instance
const client = postgres(connectionString);

/**
 * The Drizzle ORM instance. This is the main interface for all database operations.
 * It's configured with the defined schema for type safety.
 */
export const db = drizzle(client, { schema });

/**
 * Drizzle is exported directly as 'db' for use in controllers.
 * The client is exported for potential shutdown logic (though optional for serverless).
 */
export default db;

// Note: For a production app, use a connection pool instead of a single client.
// Example: const pool = postgres(connectionString, { max: 1 });
// export const db = drizzle(pool, { schema });
