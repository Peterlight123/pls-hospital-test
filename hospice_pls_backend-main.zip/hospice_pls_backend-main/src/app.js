// src/app.js

import Fastify from 'fastify';
import fastifyMultipart from '@fastify/multipart';
import fastifyAuth from '@fastify/auth'; // Placeholder for auth/middleware
import userRoutes from './routes/user.routes.js';
import { db } from './models/db.js';

// Configuration for bcrypt salt rounds
const SALT_ROUNDS = 10;

/**
 * Builds and configures the Fastify application instance.
 * @returns {object} The configured Fastify instance.
 */
async function buildApp() {
    // Initialize Fastify with logger and error handler
    const fastify = Fastify({
        logger: true // Enable logging for debugging and requests
    });

    // --- Plugins Registration ---

    // 1. Drizzle DB Connection (Not a Fastify plugin, but injecting the instance)
    // We make the DB instance available globally on the Fastify instance for controllers
    // For Drizzle, we can add it as a decorator for easy access.
    fastify.decorate('db', db);

    // 2. fastify-multipart for File Uploads (Laravel's $request->hasFile())
    await fastify.register(fastifyMultipart, {
        limits: {
            fileSize: 5 * 1024 * 1024, // 5MB limit for avatars
        },
        // We set 'attachFieldsToBody: true' so non-file fields are available on req.body
        attachFieldsToBody: 'keyValues', 
    });

    // 3. Authentication and Authorization (Spatie/JWT/Sanctum Replacement)
    // In a real app, you would register fastify-jwt/fastify-bearer-auth here.
    // We register a dummy auth plugin for structure.
    await fastify.register(fastifyAuth); 

    // --- Route Registration ---

    // Register user routes, grouped under the '/api/users' prefix
    fastify.register(userRoutes, { prefix: '/api/users' });

    // --- Error Handling Customization (Zod/Fastify Validation) ---

    // Customize the error handler to format Zod validation errors better
    fastify.setErrorHandler((error, request, reply) => {
        if (error.validation) {
            // Zod/Fastify validation error, return 400 Bad Request
            return reply.status(400).send({
                statusCode: 400,
                error: 'Bad Request',
                message: 'Request validation failed',
                details: error.validation,
            });
        }
        
        // Log all othe server errors
        request.log.error(error);
        
        // Default 500 server error response
        reply.status(error.statusCode || 500).send({
            statusCode: error.statusCode || 500,
            error: error.statusCode >= 500 ? 'Internal Server Error' : error.message,
            message: error.message
        });
    });

    return fastify;
}

export { buildApp };
