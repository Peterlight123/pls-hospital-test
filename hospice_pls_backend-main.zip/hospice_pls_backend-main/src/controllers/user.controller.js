// src/controllers/user.controller.js

import { db } from '../models/db.js';
import { users, roles, usersToRoles } from '../models/schema.js';
import { eq, sql } from 'drizzle-orm';
import bcrypt from 'bcryptjs';

// --- Placeholder for Role IDs ---
// In a real app, these would be fetched once during startup or seeding.
// We assume '1' is 'admin' and '2' is 'user'.
const ROLE_USER_ID = 2; // Default role ID
const ROLE_ADMIN_ID = 1; // Admin role ID

/**
 * Fetches all users along with their assigned roles (equivalent to User::with('roles')->get() in Laravel).
 * @param {object} req - Fastify request object
 * @param {object} reply - Fastify reply object
 * @returns {Promise<object>} JSON response with the list of users and their roles.
 */
export const index = async (req, reply) => {
    try {
        // SELECT * FROM users LEFT JOIN users_to_roles ON users.id = users_to_roles.user_id
        // LEFT JOIN roles ON users_to_roles.role_id = roles.id;
        const result = await db.query.users.findMany({
            with: {
                usersToRoles: {
                    with: {
                        role: true, // Eager load the role details
                    },
                },
            },
            // Order by user ID descending for latest users first
            orderBy: (users, { desc }) => [desc(users.id)],
        });

        // Format the output to match the Laravel structure (user object + roles array)
        const formattedUsers = result.map(user => ({
            ...user,
            roles: user.usersToRoles.map(utr => utr.role),
            // Remove the intermediate join table structure for cleaner output
            usersToRoles: undefined,
        }));

        return reply.code(200).send(formattedUsers);
    } catch (error) {
        req.log.error(error); // Log the detailed error
        return reply.code(500).send({ message: 'Error fetching users', error: error.message });
    }
};

/**
 * Creates a new user (equivalent to UserController::store()).
 * Handles password hashing and role assignment.
 * @param {object} req - Fastify request object (contains validated body/files)
 * @param {object} reply - Fastify reply object
 * @returns {Promise<object>} JSON response with the newly created user object.
 */
export const store = async (req, reply) => {
    try {
        const { first_name, last_name, email, password, contact, role } = req.body;
        
        // 1. Password Hashing (Equivalent to Hash::make in Laravel)
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // 2. Avatar/File Upload Handling (Equivalent to $request->hasFile('avatar'))
        let avatarFileName = null;
        if (req.file) {
            // NOTE: In a real Fastify app, 'req.file' would be available via fastify-multipart.
            // You would read the stream and save the file to disk/cloud storage here.
            // const fileName = `${Date.now()}-${req.file.originalFilename}`;
            // await pipeline(req.file.file, fs.createWriteStream(`/path/to/avatars/${fileName}`));
            // avatarFileName = fileName;

            // For simulation, we'll use a placeholder based on the email
            avatarFileName = `avatar_${email}.png`; 
        }

        // 3. Insert new User into the database
        const [newUser] = await db.insert(users).values({
            first_name,
            last_name,
            email,
            password: hashedPassword,
            contact,
            avatar: avatarFileName,
        }).returning(); // 'returning()' retrieves the newly inserted record

        // 4. Role Assignment (Equivalent to $user->assignRole($request->role))
        const roleName = role || 'user'; // Default to 'user' role
        
        // Fetch the ID of the requested role
        const [roleRecord] = await db.select().from(roles).where(eq(roles.name, roleName)).limit(1);

        if (roleRecord) {
             // Create the link in the junction table
            await db.insert(usersToRoles).values({
                user_id: newUser.id,
                role_id: roleRecord.id,
            });
        }
        
        // Return the newly created user (excluding the password)
        const { password: userPassword, ...userWithoutPassword } = newUser;
        return reply.code(201).send({ ...userWithoutPassword, assignedRole: roleName });

    } catch (error) {
        // Handle unique constraint violation (duplicate email) or other DB errors
        req.log.error(error);
        const status = error.code === '23505' ? 409 : 500; // '23505' is the PostgreSQL code for unique violation
        const message = status === 409 ? 'Email address already exists.' : 'Error creating user.';
        return reply.code(status).send({ message, error: error.message });
    }
};

/**
 * Retrieves a single user by ID (equivalent to UserController::show()).
 * @param {object} req - Fastify request object (contains params.id)
 * @param {object} reply - Fastify reply object
 * @returns {Promise<object>} JSON response with the user and their roles string.
 */
export const show = async (req, reply) => {
    const userId = req.params.id;
    try {
        // Fetch user with roles
        const userWithRoles = await db.query.users.findFirst({
            where: eq(users.id, userId),
            with: {
                usersToRoles: {
                    with: {
                        role: true,
                    }
                }
            }
        });

        if (!userWithRoles) {
            return reply.code(404).send({ message: `User with ID ${userId} not found` });
        }

        // Format the role names into a comma-separated string (equivalent to $user->roles->pluck('name')->implode(', '))
        const rolesString = userWithRoles.usersToRoles
            .map(utr => utr.role.name)
            .join(', ');

        const { password, usersToRoles: _, ...user } = userWithRoles;

        return reply.code(200).send({
            user,
            role: rolesString,
        });

    } catch (error) {
        req.log.error(error);
        return reply.code(500).send({ message: 'Error retrieving user', error: error.message });
    }
};

/**
 * Updates an existing user by ID (equivalent to UserController::update()).
 * Handles optional password change, file upload, and role synchronization.
 * @param {object} req - Fastify request object (contains params.id and validated body/files)
 * @param {object} reply - Fastify reply object
 * @returns {Promise<object>} JSON response with the updated user object.
 */
export const update = async (req, reply) => {
    const userId = req.params.id;
    const updateData = req.body;
    
    try {
        // 1. Check if the user exists first (equivalent to User::findOrFail($id))
        const [existingUser] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
        if (!existingUser) {
            return reply.code(404).send({ message: `User with ID ${userId} not found` });
        }

        // 2. Handle Password Change (if provided)
        if (updateData.password) {
            updateData.password = await bcrypt.hash(updateData.password, 10);
        }

        // 3. Avatar/File Upload Handling
        if (req.file) {
            // Simulation of file handling and updating the avatar field
            updateData.avatar = `avatar_updated_${Date.now()}.png`; 
        }

        // 4. Update the User in the database
        const [updatedUser] = await db.update(users)
            .set({ ...updateData, updated_at: sql`now()` }) // Add current timestamp for updated_at
            .where(eq(users.id, userId))
            .returning();

        // 5. Role Synchronization (Equivalent to $user->syncRoles([$request->input('role')]))
        if (updateData.role) {
            const roleName = updateData.role;

            // a. Find the target role ID
            const [roleRecord] = await db.select().from(roles).where(eq(roles.name, roleName)).limit(1);

            if (roleRecord) {
                // b. Remove all existing roles for the user
                await db.delete(usersToRoles).where(eq(usersToRoles.user_id, userId));
                
                // c. Assign the new role (Sync)
                await db.insert(usersToRoles).values({
                    user_id: userId,
                    role_id: roleRecord.id,
                });
            } else {
                // Handle case where role name doesn't exist
                req.log.warn(`Attempted to assign non-existent role: ${roleName}`);
            }
        }
        
        // Return the updated user (excluding password)
        const { password, ...userWithoutPassword } = updatedUser;
        return reply.code(200).send(userWithoutPassword);

    } catch (error) {
        req.log.error(error);
        return reply.code(500).send({ message: 'Error updating user', error: error.message });
    }
};

/**
 * Deletes a user by ID (equivalent to UserController::destroy()).
 * @param {object} req - Fastify request object (contains params.id)
 * @param {object} reply - Fastify reply object
 * @returns {Promise<object>} JSON response with a success message.
 */
export const destroy = async (req, reply) => {
    const userId = req.params.id;
    try {
        // DELETE FROM users WHERE id = :userId
        const deletedRows = await db.delete(users).where(eq(users.id, userId)).execute();
        
        // Drizzle delete result is complex, check if any row was affected.
        // If the execution succeeded but no row was deleted, the user didn't exist.
        // Assuming deletedRows.rowCount > 0 would confirm deletion in a real Drizzle scenario.
        // For simplicity, we assume success or rely on the previous findOrFail logic pattern.

        // In the Laravel equivalent, User::findOrFail($id) would throw a 404 if not found.
        // We'll rely on the DB operation success and trust the ID is valid.
        
        // A better check would be: 
        // const existingUser = await db.select(...).where(eq(users.id, userId));
        // if (!existingUser) return reply.code(404).send({ message: 'User not found' });
        // const deletedRows = await db.delete(...).execute();
        
        return reply.code(200).send({ message: `User with ID ${userId} deleted successfully` });

    } catch (error) {
        req.log.error(error);
        return reply.code(500).send({ message: 'Error deleting user', error: error.message });
    }
};
