// src/server.js

import { buildApp } from './app.js';

// Set up server constants
const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0'; // Listen on all interfaces

/**
 * Main function to start the Fastify server.
 */
async function startServer() {
    try {
        // Build the configured Fastify application instance
        const fastify = await buildApp();

        // Start the server
        await fastify.listen({ port: PORT, host: HOST });
        
        // Log successful startup
        fastify.log.info(`Server listening on ${fastify.server.address().port}`);
    } catch (err) {
        // Log and exit if server startup fails
        console.error('Server startup failed:', err);
        process.exit(1);
    }
}

// Execute the server start function
startServer();
