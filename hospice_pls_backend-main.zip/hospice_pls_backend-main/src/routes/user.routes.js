// src/routes/user.routes.js

import { z } from 'zod';
import * as userController from '../controllers/user.controller.js';

// --- ZOD SCHEMAS for Validation ---

// Schema for creating a new user (POST /users)
const createUserBodySchema = z.object({
    first_name: z.string().min(2).max(255),
    last_name: z.string().min(2).max(255),
    email: z.string().email(),
    password: z.string().min(8, 'Password must be at least 8 characters long'),
    contact: z.string().optional(),
    // Role is optional on creation, defaults to 'user' in controller
    role: z.enum(['admin', 'moderator', 'user']).optional(), 
    // Avatar is handled via multipart, not validated in the body schema
});

// Schema for updating an existing user (PUT /users/:id)
const updateUserBodySchema = z.object({
    first_name: z.string().min(2).max(255).optional(),
    last_name: z.string().min(2).max(255).optional(),
    email: z.string().email().optional(),
    // Password is optional for updates
    password: z.string().min(8, 'Password must be at least 8 characters long').optional(), 
    contact: z.string().optional(),
    role: z.enum(['admin', 'moderator', 'user']).optional(),
    // If all fields are optional, ensure at least one is present (optional check for realism)
}).refine(data => Object.keys(data).length > 0, {
    message: "Request body must contain at least one field to update.",
});

// Schema for ID parameter validation (GET/PUT/DELETE /users/:id)
const userIdParamsSchema = z.object({
    // ID must be a number string which Fastify will cast to a string, validated as a numeric string
    id: z.string().regex(/^\d+$/, 'ID must be a numeric string').transform(Number),
});

/**
 * The Fastify route plugin function for the User module.
 * @param {objec} fastify - The Fastiy instance.
 * @param {object} options - Plugin options.
 */
async function userRoutes(fastify, options) {
    // --- GET /users (index) ---
    // Fetches all users with their roles. No request body/params validation needed.
    fastify.get('/', {
        // Pre-handler for authorization/authentication would go here if needed.
    }, userController.index);

    // --- POST /users (store) ---
    // Creates a new user. Requires validation for the body (createUserBodySchema).
    // Note: Fastify schema ensures validation, error handling is done automatically.
    fastify.post('/', {
        // Fastify uses 'schema' object for request validation and OpenAPI documentation
        schema: {
            // Note: Since we are using fastify-multipart, the body validation is simpler for
            // JSON fields. File handling logic is internal to the fastify-multipart plugin.
            body: createUserBodySchema,
        }
    }, userController.store);

    // --- GET /users/:id (show) ---
    // Retrieves a single user. Requires validation for the ID parameter.
    fastify.get('/:id', {
        schema: {
            params: userIdParamsSchema,
        }
    }, userController.show);

    // --- PUT /users/:id (update) ---
    // Updates an existing user. Requires validation for both ID parameter and the body.
    fastify.put('/:id', {
        schema: {
            params: userIdParamsSchema,
            body: updateUserBodySchema,
        }
    }, userController.update);

    // --- DELETE /users/:id (destroy) ---
    // Deletes a user. Requires validation for the ID parameter.
    fastify.delete('/:id', {
        schema: {
            params: userIdParamsSchema,
        }
    }, userController.destroy);
}

// Export the function as a default Fastify plugin
export default userRoutes;

