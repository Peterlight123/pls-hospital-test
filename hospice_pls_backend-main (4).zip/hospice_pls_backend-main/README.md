# Healthcare Patient Management System - Node.js Backend

**Converted from Laravel to Node.js with Fastify, Drizzle ORM, and PostgreSQL**

## Project Overview

This is a comprehensive healthcare patient management system backend that handles:
- Patient records and management
- Pain assessments and tracking
- Medical assessments (Cardiac, Endocrine, Hematological, Integumentary)
- Nursing clinical notes
- Benefit periods
- User authentication and authorization (JWT)
- Role-based access control (RBAC)

## Project Structure

```
/
├── server.js                 # Main server entry point
├── package.json             # Dependencies and scripts
├── drizzle.config.js        # Drizzle ORM configuration
├── src/
│   ├── config/
│   │   └── database.js      # Database connection setup
│   ├── db/
│   │   └── schema.js        # Drizzle ORM schema definitions
│   ├── routes/
│   │   ├── auth.js          # Authentication routes
│   │   └── patients.js      # Patient management routes
│   ├── controllers/
│   │   ├── authController.js      # Auth logic (login, register)
│   │   └── patientController.js   # Patient CRUD operations
│   ├── middlewares/
│   │   └── auth.js          # JWT authentication middleware
│   └── utils/
│       └── hash.js          # Password hashing utilities
└── laravel_original/        # Original Laravel project (reference)
```

## Quick Start

### Prerequisites
- Node.js 20+ installed
- PostgreSQL database (optional for now)

### Installation

1. **Install dependencies:**
```bash
npm install
```

2. **Start the server:**
```bash
npm run dev
```

The server will start on `http://localhost:3000`

### Test the server:
```bash
curl http://localhost:3000/ping
```

Expected response:
```json
{
  "message": "pong",
  "status": "ok",
  "timestamp": "2025-11-04T10:14:03.266Z"
}
```

## Database Setup (Optional - Add Later)

The application is currently configured to run WITHOUT a database for testing purposes. When you're ready to add database functionality:

### Step 1: Create PostgreSQL Database
1. In Replit, go to the **Database** tab in the left sidebar
2. Click "Create Database" and select PostgreSQL
3. Copy the connection string

### Step 2: Add DATABASE_URL Secret
1. Go to **Secrets** (Tools > Secrets) in Replit
2. Add a new secret:
   - Key: `DATABASE_URL`
   - Value: Your PostgreSQL connection string

### Step 3: Generate and Run Migrations
```bash
# Generate migration files from schema
npm run db:generate

# Push schema to database (creates all tables)
npm run db:push
```

### Step 4: Restart the Server
The server will automatically connect to the database on restart.

## Authentication

### JWT Secret
The server uses JWT for authentication. Add your JWT secret:
1. Go to **Secrets** in Replit
2. Add: `JWT_SECRET` with a long random string

Or it will use the default (not recommended for production).

## API Endpoints

### Public Endpoints

#### Health Check
```
GET /ping
```

#### Authentication
```
POST /api/register
Body: { firstName, lastName, contact, email, password }

POST /api/login
Body: { email, password }

POST /api/logout
```

### Protected Endpoints (Requires JWT Token)

#### Patients
```
GET    /api/patient          # Get all patients
POST   /api/patient/store    # Create new patient
GET    /api/patient/:id      # Get patient by ID
PUT    /api/patient/:id      # Update patient
DELETE /api/patient/:id      # Delete patient
```

### Using Protected Endpoints

1. **Login to get token:**
```bash
curl -X POST http://localhost:3000/api/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"password123"}'
```

2. **Use token in subsequent requests:**
```bash
curl http://localhost:3000/api/patient \
  -H "Authorization: Bearer YOUR_JWT_TOKEN_HERE"
```

## Laravel to Fastify Conversion Summary

### Main Folder Conversions

| Laravel Folder | Fastify Equivalent | Purpose |
|---------------|-------------------|---------|
| `routes/api.php` | `src/routes/*.js` | API route definitions |
| `app/Http/Controllers/` | `src/controllers/` | Business logic handlers |
| `app/Models/` | `src/db/schema.js` | Database models (Drizzle ORM) |
| `app/Http/Middleware/` | `src/middlewares/` | Request interceptors |
| `config/` | `src/config/` | Configuration files |
| `database/migrations/` | `drizzle.config.js` + schema | Database schema management |

### Technology Stack Mapping

| Laravel | Fastify Equivalent |
|---------|-------------------|
| Laravel Framework | Fastify |
| Eloquent ORM | Drizzle ORM |
| MySQL/PostgreSQL | PostgreSQL |
| Blade Templates | N/A (API only) |
| Laravel Sanctum/Passport | @fastify/jwt |
| Spatie Permissions | Custom RBAC (schema ready) |

## Remaining Laravel Files to Convert

The current implementation includes:
- ✅ Core server setup (Fastify)
- ✅ Database configuration (Drizzle ORM)
- ✅ Authentication system (JWT)
- ✅ Patient management (CRUD)
- ✅ Database schema for all models

**Still to be converted:**
1. All other patient-related controllers:
   - Pain Assessment Controllers
   - Medical Assessment Controllers (Cardiac, Endocrine, etc.)
   - Nursing Clinical Notes
   - Benefit Periods
   - Address, Payer Information, etc.

2. Role and Permission Management:
   - RoleController
   - PermissionController
   - User management

3. Lookup/Select Controllers:
   - DME Providers
   - Patient Pharmacies
   - Primary Diagnoses
   - DNR, Race/Ethnicity, etc.

4. Advanced Features:
   - PDF generation
   - File uploads
   - Discharge management
   - Signature handling

## Available NPM Scripts

```bash
npm run dev        # Start development server with auto-reload
npm start          # Start production server
npm run db:generate # Generate Drizzle migration files
npm run db:migrate  # Run migrations
npm run db:push     # Push schema to database (dev)
npm run db:studio   # Open Drizzle Studio (GUI for database)
```

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `PORT` | Server port (default: 3000) | No |
| `HOST` | Server host (default: 0.0.0.0) | No |
| `NODE_ENV` | Environment (development/production) | No |
| `DATABASE_URL` | PostgreSQL connection string | Yes (for DB features) |
| `JWT_SECRET` | Secret key for JWT tokens | Recommended |
| `JWT_EXPIRES_IN` | Token expiration time (default: 7d) | No |

## Database Schema Overview

The schema includes all tables from the Laravel project:

### Core Tables
- `users` - System users with authentication
- `roles` - User roles
- `permissions` - System permissions
- `patients` - Patient records

### Lookup Tables
- `dme_providers` - DME equipment providers
- `patient_pharmacies` - Patient pharmacy information
- `primary_diagnoses` - Primary diagnosis types
- `dnr` - DNR status options
- `race_ethnicity` - Race and ethnicity categories
- `emergency_preparedness_level` - Emergency preparedness levels
- `liaison_primary` / `liaison_secondary` - Liaison contacts

### Clinical Tables
- `benefit_periods` - Patient benefit periods
- `patient_identifiers` - Additional patient identifiers
- `pain_assessments` - Pain assessment records
- `signatures` - Digital signatures

## Code Examples

### Example 1: Creating a Patient (with database)

```javascript
const response = await fetch('http://localhost:3000/api/patient/store', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_TOKEN'
  },
  body: JSON.stringify({
    first_name: 'John',
    last_name: 'Doe',
    mi: 'A',
    preferred_name: 'Johnny',
    date_of_birth: '1980-01-15',
    suffix: 'Jr',
    ssn: 123456789,
    genders: 'Male',
    oxygen_dependent: false,
    patient_consents: true,
    hipaa_received: true,
    dnr_id: 1,
    race_ethnicity_id: 1,
    liaison_primary_id: 1,
    liaison_secondary_id: 1,
    emergency_preparedness_level_id: 1,
    dme_provider_id: 1,
    primary_diagnosis_id: 1,
    patient_pharmacy_id: 1
  })
});
```

### Example 2: Custom Route (How to Add)

**src/routes/customRoute.js**
```javascript
export default async function customRoutes(fastify, options) {
  fastify.get('/custom-endpoint', async (request, reply) => {
    return { message: 'Custom endpoint' };
  });
}
```

**server.js** (register the route)
```javascript
import customRoutes from './src/routes/customRoute.js';
await fastify.register(customRoutes, { prefix: '/api' });
```

## Security Best Practices

1. **Always use HTTPS in production**
2. **Set strong JWT_SECRET** (long random string)
3. **Use environment variables** for sensitive data
4. **Enable rate limiting** for production
5. **Validate all user inputs** (JSON schemas in routes)
6. **Hash passwords** (already implemented with bcrypt)

## Learning Resources

- [Fastify Documentation](https://fastify.dev)
- [Drizzle ORM Documentation](https://orm.drizzle.team)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [JWT Best Practices](https://jwt.io/introduction)

## Contributing

When adding new features:
1. Create controller in `src/controllers/`
2. Define routes in `src/routes/`
3. Add schema definitions to `src/db/schema.js` if needed
4. Update this README

## License

MIT

---

**Note:** This is a work in progress. The core infrastructure is complete, but many Laravel controllers still need to be converted. Refer to the "Remaining Laravel Files to Convert" section above for the full list.
