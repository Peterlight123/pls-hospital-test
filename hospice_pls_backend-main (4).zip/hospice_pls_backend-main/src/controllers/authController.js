import { db } from '../config/database.js';
import { users } from '../db/schema.js';
import { hashPassword, verifyPassword } from '../utils/hash.js';
import { eq } from 'drizzle-orm';

// Helper function to check database availability
const checkDatabase = (reply) => {
  if (!db) {
    return reply.code(503).send({
      error: 'Database not configured',
      message: 'Please set DATABASE_URL environment variable and restart the server',
    });
  }
  return null;
};

// Register a new user
export const register = async (request, reply) => {
  const dbCheck = checkDatabase(reply);
  if (dbCheck) return dbCheck;

  try {
    const { firstName, lastName, contact, email, password } = request.body;

    // Check if user already exists
    const existingUser = await db.select().from(users).where(eq(users.email, email)).limit(1);
    
    if (existingUser.length > 0) {
      return reply.code(409).send({
        error: 'User already exists with this email'
      });
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Create new user
    const [newUser] = await db.insert(users).values({
      firstName,
      lastName,
      contact,
      email,
      password: hashedPassword,
    }).returning({
      id: users.id,
      firstName: users.firstName,
      lastName: users.lastName,
      contact: users.contact,
      email: users.email,
    });

    // Generate JWT token
    const token = request.server.jwt.sign({
      id: newUser.id,
      email: newUser.email,
    });

    return reply.code(201).send({
      message: 'User registered successfully',
      data: newUser,
      token,
    });
  } catch (error) {
    request.log.error(error);
    return reply.code(500).send({
      error: 'Internal server error',
      message: error.message,
    });
  }
};

// Login user
export const login = async (request, reply) => {
  const dbCheck = checkDatabase(reply);
  if (dbCheck) return dbCheck;

  try {
    const { email, password } = request.body;

    // Find user by email
    const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);

    if (!user) {
      return reply.code(401).send({
        error: 'Invalid credentials',
        message: 'Email or password is incorrect',
      });
    }

    // Verify password
    const isValidPassword = await verifyPassword(password, user.password);

    if (!isValidPassword) {
      return reply.code(401).send({
        error: 'Invalid credentials',
        message: 'Email or password is incorrect',
      });
    }

    // Generate JWT token
    const token = request.server.jwt.sign({
      id: user.id,
      email: user.email,
    });

    // Return user data without password
    const { password: _, ...userData } = user;

    return reply.send({
      message: 'Login successful',
      data: userData,
      token,
    });
  } catch (error) {
    request.log.error(error);
    return reply.code(500).send({
      error: 'Internal server error',
      message: error.message,
    });
  }
};

// Logout user
export const logout = async (request, reply) => {
  return reply.send({
    message: 'Logout successful',
  });
};
