import { db } from '../config/database.js';
import {
  patients,
  dmeProviders,
  patientPharmacies,
  primaryDiagnoses,
  raceEthnicity,
  emergencyPreparednessLevel,
  benefitPeriods,
} from '../db/schema.js';
import { eq } from 'drizzle-orm';

// Helper function to check database availability
const checkDatabase = (reply) => {
  if (!db) {
    return reply.code(503).send({
      error: 'Database not configured',
      message: 'Please set DATABASE_URL environment variable and restart the server',
    });
  }
  return null;
};

// Get all patients with related data
export const index = async (request, reply) => {
  const dbCheck = checkDatabase(reply);
  if (dbCheck) return dbCheck;

  try {
    const allPatients = await db
      .select({
        id: patients.id,
        firstName: patients.firstName,
        preferredName: patients.preferredName,
        mi: patients.mi,
        suffix: patients.suffix,
        lastName: patients.lastName,
        oxygenDependent: patients.oxygenDependent,
        patientConsents: patients.patientConsents,
        ssn: patients.ssn,
        genders: patients.genders,
        dateOfBirth: patients.dateOfBirth,
        raceEthnicityName: raceEthnicity.name,
        dmeProviderName: dmeProviders.name,
        primaryDiagnosisName: primaryDiagnoses.name,
        patientPharmacyName: patientPharmacies.name,
        emergencyPreparednessLevelName: emergencyPreparednessLevel.name,
      })
      .from(patients)
      .leftJoin(patientPharmacies, eq(patients.patientPharmacyId, patientPharmacies.id))
      .leftJoin(dmeProviders, eq(patients.dmeProviderId, dmeProviders.id))
      .leftJoin(primaryDiagnoses, eq(patients.primaryDiagnosisId, primaryDiagnoses.id))
      .leftJoin(raceEthnicity, eq(patients.raceEthnicityId, raceEthnicity.id))
      .leftJoin(
        emergencyPreparednessLevel,
        eq(patients.emergencyPreparednessLevelId, emergencyPreparednessLevel.id)
      );

    return reply.send(allPatients);
  } catch (error) {
    request.log.error(error);
    return reply.code(500).send({
      error: 'Internal server error',
      message: error.message,
    });
  }
};

// Get single patient by ID
export const show = async (request, reply) => {
  const dbCheck = checkDatabase(reply);
  if (dbCheck) return dbCheck;

  try {
    const { id } = request.params;

    const [patient] = await db
      .select()
      .from(patients)
      .where(eq(patients.id, parseInt(id)))
      .limit(1);

    if (!patient) {
      return reply.code(404).send({
        error: 'No Patient found.',
      });
    }

    return reply.send(patient);
  } catch (error) {
    request.log.error(error);
    return reply.code(500).send({
      error: 'Internal server error',
      message: error.message,
    });
  }
};

// Create a new patient
export const store = async (request, reply) => {
  const dbCheck = checkDatabase(reply);
  if (dbCheck) return dbCheck;

  try {
    const patientData = request.body;

    // Create patient
    const [newPatient] = await db
      .insert(patients)
      .values({
        firstName: patientData.first_name,
        mi: patientData.mi,
        lastName: patientData.last_name,
        preferredName: patientData.preferred_name,
        dateOfBirth: patientData.date_of_birth,
        dnrId: patientData.dnr_id,
        recert: patientData.recert,
        suffix: patientData.suffix,
        ssn: patientData.ssn,
        hipaaReceived: patientData.hipaa_received,
        raceEthnicityId: patientData.race_ethnicity_id,
        liaisonPrimaryId: patientData.liaison_primary_id,
        liaisonSecondaryId: patientData.liaison_secondary_id,
        emergencyPreparednessLevelId: patientData.emergency_preparedness_level_id,
        oxygenDependent: patientData.oxygen_dependent,
        patientConsents: patientData.patient_consents,
        genders: patientData.genders,
        dmeProviderId: patientData.dme_provider_id,
        primaryDiagnosisId: patientData.primary_diagnosis_id,
        patientPharmacyId: patientData.patient_pharmacy_id,
      })
      .returning();

    // Create benefit period
    const startDate = new Date();
    const endDate = new Date();
    endDate.setMonth(endDate.getMonth() + 3);

    await db.insert(benefitPeriods).values({
      patientId: newPatient.id,
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0],
      periodNumber: 1,
    });

    return reply.code(200).send({
      message: 'Patient created successfully',
      data: newPatient,
    });
  } catch (error) {
    request.log.error(error);
    return reply.code(500).send({
      error: 'Internal server error',
      message: error.message,
    });
  }
};

// Update patient
export const update = async (request, reply) => {
  const dbCheck = checkDatabase(reply);
  if (dbCheck) return dbCheck;

  try {
    const { id } = request.params;
    const patientData = request.body;

    const [updatedPatient] = await db
      .update(patients)
      .set({
        firstName: patientData.first_name,
        mi: patientData.mi,
        lastName: patientData.last_name,
        preferredName: patientData.preferred_name,
        dateOfBirth: patientData.date_of_birth,
        dnrId: patientData.dnr_id,
        recert: patientData.recert,
        suffix: patientData.suffix,
        ssn: patientData.ssn,
        hipaaReceived: patientData.hipaa_received,
        raceEthnicityId: patientData.race_ethnicity_id,
        liaisonPrimaryId: patientData.liaison_primary_id,
        liaisonSecondaryId: patientData.liaison_secondary_id,
        emergencyPreparednessLevelId: patientData.emergency_preparedness_level_id,
        oxygenDependent: patientData.oxygen_dependent,
        patientConsents: patientData.patient_consents,
        genders: patientData.genders,
        dmeProviderId: patientData.dme_provider_id,
        primaryDiagnosisId: patientData.primary_diagnosis_id,
        patientPharmacyId: patientData.patient_pharmacy_id,
        updatedAt: new Date(),
      })
      .where(eq(patients.id, parseInt(id)))
      .returning();

    if (!updatedPatient) {
      return reply.code(404).send({
        error: 'Patient not found.',
      });
    }

    return reply.send({
      message: 'Patient update successfully',
      data: updatedPatient,
    });
  } catch (error) {
    request.log.error(error);
    return reply.code(500).send({
      error: 'Internal server error',
      message: error.message,
    });
  }
};

// Delete patient
export const destroy = async (request, reply) => {
  const dbCheck = checkDatabase(reply);
  if (dbCheck) return dbCheck;

  try {
    const { id } = request.params;

    const [deletedPatient] = await db
      .delete(patients)
      .where(eq(patients.id, parseInt(id)))
      .returning();

    if (!deletedPatient) {
      return reply.code(404).send({
        error: 'Patient not found.',
      });
    }

    return reply.send({
      message: 'Patient delete successfully',
    });
  } catch (error) {
    request.log.error(error);
    return reply.code(500).send({
      error: 'Internal server error',
      message: error.message,
    });
  }
};
