import { register, login, logout } from '../controllers/authController.js';

// Authentication routes
export default async function authRoutes(fastify, options) {
  // Register schema for validation
  const registerSchema = {
    body: {
      type: 'object',
      required: ['email', 'password'],
      properties: {
        firstName: { type: 'string' },
        lastName: { type: 'string' },
        contact: { type: 'string' },
        email: { type: 'string', format: 'email' },
        password: { type: 'string', minLength: 6 },
      },
    },
  };

  const loginSchema = {
    body: {
      type: 'object',
      required: ['email', 'password'],
      properties: {
        email: { type: 'string', format: 'email' },
        password: { type: 'string' },
      },
    },
  };

  // Public routes
  fastify.post('/register', { schema: registerSchema }, register);
  fastify.post('/login', { schema: loginSchema }, login);
  fastify.post('/logout', logout);
}
