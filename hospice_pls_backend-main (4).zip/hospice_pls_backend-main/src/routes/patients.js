import { index, show, store, update, destroy } from '../controllers/patientController.js';
import { authMiddleware } from '../middlewares/auth.js';

// Patient routes
export default async function patientRoutes(fastify, options) {
  // Apply auth middleware to all routes in this plugin
  fastify.addHook('preHandler', authMiddleware);

  // CRUD routes for patients
  fastify.get('/patient', index);
  fastify.post('/patient/store', store);
  fastify.get('/patient/:id', show);
  fastify.put('/patient/:id', update);
  fastify.delete('/patient/:id', destroy);
}
