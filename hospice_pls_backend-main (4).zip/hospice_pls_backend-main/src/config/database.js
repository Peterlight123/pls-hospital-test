import { drizzle } from 'drizzle-orm/node-postgres';
import pkg from 'pg';
const { Pool } = pkg;
import * as schema from '../db/schema.js';

// TODO: Uncomment this when you have DATABASE_URL configured
// Database connection pool configuration
let db = null;
let pool = null;

if (process.env.DATABASE_URL) {
  pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
  });
  
  // Create Drizzle ORM instance with schema
  db = drizzle(pool, { schema });
  console.log('✅ Database connected successfully');
} else {
  console.log('⚠️  DATABASE_URL not set - running without database');
  console.log('📝 To add database:');
  console.log('   1. Create a PostgreSQL database in Replit (Database tab)');
  console.log('   2. Add DATABASE_URL secret with your connection string');
  console.log('   3. Run: npm run db:push (to create tables)');
  console.log('   4. Restart the server');
}

export { db };

// Close database connections on shutdown
export const closeDatabase = async () => {
  if (pool) {
    await pool.end();
  }
};
