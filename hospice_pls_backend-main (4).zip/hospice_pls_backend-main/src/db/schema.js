import { pgTable, serial, varchar, text, timestamp, boolean, integer, bigint, date, unique, foreignKey, index, primaryKey } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

// Users table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  firstName: varchar('first_name', { length: 255 }),
  lastName: varchar('last_name', { length: 255 }),
  contact: varchar('contact', { length: 255 }),
  email: varchar('email', { length: 255 }).notNull().unique(),
  image: varchar('image', { length: 255 }),
  emailVerifiedAt: timestamp('email_verified_at'),
  password: varchar('password', { length: 255 }).notNull(),
  rememberToken: varchar('remember_token', { length: 100 }),
  avatar: varchar('avatar', { length: 255 }),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Permissions table
export const permissions = pgTable('permissions', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  guardName: varchar('guard_name', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
}, (table) => ({
  nameGuardUnique: unique().on(table.name, table.guardName),
}));

// Roles table
export const roles = pgTable('roles', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  guardName: varchar('guard_name', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
}, (table) => ({
  nameGuardUnique: unique().on(table.name, table.guardName),
}));

// Model has permissions pivot table
export const modelHasPermissions = pgTable('model_has_permissions', {
  permissionId: integer('permission_id').notNull().references(() => permissions.id, { onDelete: 'cascade' }),
  modelType: varchar('model_type', { length: 255 }).notNull(),
  modelId: bigint('model_id', { mode: 'number' }).notNull(),
}, (table) => ({
  pk: primaryKey({ columns: [table.permissionId, table.modelId, table.modelType] }),
}));

// Model has roles pivot table
export const modelHasRoles = pgTable('model_has_roles', {
  roleId: integer('role_id').notNull().references(() => roles.id, { onDelete: 'cascade' }),
  modelType: varchar('model_type', { length: 255 }).notNull(),
  modelId: bigint('model_id', { mode: 'number' }).notNull(),
}, (table) => ({
  pk: primaryKey({ columns: [table.roleId, table.modelId, table.modelType] }),
}));

// Role has permissions pivot table
export const roleHasPermissions = pgTable('role_has_permissions', {
  permissionId: integer('permission_id').notNull().references(() => permissions.id, { onDelete: 'cascade' }),
  roleId: integer('role_id').notNull().references(() => roles.id, { onDelete: 'cascade' }),
}, (table) => ({
  pk: primaryKey({ columns: [table.permissionId, table.roleId] }),
}));

// DME Providers table
export const dmeProviders = pgTable('dme_providers', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Patient Pharmacies table
export const patientPharmacies = pgTable('patient_pharmacies', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Primary Diagnoses table
export const primaryDiagnoses = pgTable('primary_diagnoses', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// DNR table
export const dnr = pgTable('dnr', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Race Ethnicity table
export const raceEthnicity = pgTable('race_ethnicity', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Emergency Preparedness Level table
export const emergencyPreparednessLevel = pgTable('emergency_preparedness_level', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Liaison Primary table
export const liaisonPrimary = pgTable('liaison_primary', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Liaison Secondary table
export const liaisonSecondary = pgTable('liaison_secondary', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Patients table
export const patients = pgTable('patients', {
  id: serial('id').primaryKey(),
  firstName: varchar('first_name', { length: 255 }).notNull(),
  mi: varchar('mi', { length: 255 }).notNull(),
  lastName: varchar('last_name', { length: 255 }).notNull(),
  preferredName: varchar('preferred_name', { length: 255 }).notNull(),
  dateOfBirth: date('date_of_birth').notNull(),
  suffix: varchar('suffix', { length: 255 }).notNull(),
  oxygenDependent: boolean('oxygen_dependent').notNull(),
  ssn: bigint('ssn', { mode: 'number' }).notNull(),
  patientConsents: boolean('patient_consents').notNull(),
  genders: varchar('genders', { length: 255 }).notNull(),
  dmeProviderId: integer('dme_provider_id').notNull().references(() => dmeProviders.id, { onDelete: 'no action' }),
  primaryDiagnosisId: integer('primary_diagnosis_id').notNull().references(() => primaryDiagnoses.id, { onDelete: 'no action' }),
  patientPharmacyId: integer('patient_pharmacy_id').notNull().references(() => patientPharmacies.id, { onDelete: 'no action' }),
  dnrId: integer('dnr_id').notNull().references(() => dnr.id, { onDelete: 'no action' }),
  raceEthnicityId: integer('race_ethnicity_id').notNull().references(() => raceEthnicity.id, { onDelete: 'no action' }),
  emergencyPreparednessLevelId: integer('emergency_preparedness_level_id').notNull().references(() => emergencyPreparednessLevel.id, { onDelete: 'no action' }),
  liaisonPrimaryId: integer('liaison_primary_id').notNull().references(() => liaisonPrimary.id, { onDelete: 'no action' }),
  liaisonSecondaryId: integer('liaison_secondary_id').notNull().references(() => liaisonSecondary.id, { onDelete: 'no action' }),
  hipaaReceived: boolean('hipaa_received').notNull(),
  recert: varchar('recert', { length: 255 }),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Benefit Periods table
export const benefitPeriods = pgTable('benefit_periods', {
  id: serial('id').primaryKey(),
  patientId: integer('patient_id').notNull().references(() => patients.id, { onDelete: 'cascade' }),
  startDate: date('start_date').notNull(),
  endDate: date('end_date'),
  periodNumber: integer('period_number').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Patient Identifiers table
export const patientIdentifiers = pgTable('patient_identifiers', {
  id: serial('id').primaryKey(),
  patientId: integer('patient_id').notNull().references(() => patients.id, { onDelete: 'cascade' }),
  identifierType: varchar('identifier_type', { length: 255 }).notNull(),
  identifierValue: varchar('identifier_value', { length: 255 }).notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Pain Assessments table
export const painAssessments = pgTable('pain_assessments', {
  id: serial('id').primaryKey(),
  patientId: integer('patient_id').notNull().references(() => patients.id, { onDelete: 'cascade' }),
  painLevelNow: integer('pain_level_now'),
  acceptableLevelOfPain: integer('acceptable_level_of_pain'),
  worstPainLevel: integer('worst_pain_level'),
  primaryPainSite: varchar('primary_pain_site', { length: 255 }),
  bestPainLevel: varchar('best_pain_level', { length: 255 }),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Signatures table
export const signatures = pgTable('signatures', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').notNull(),
  signatureData: text('signature_data').notNull(),
  createdAt: timestamp('created_at').defaultNow(),
  updatedAt: timestamp('updated_at').defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  signatures: many(signatures),
}));

export const patientsRelations = relations(patients, ({ one, many }) => ({
  dmeProvider: one(dmeProviders, {
    fields: [patients.dmeProviderId],
    references: [dmeProviders.id],
  }),
  primaryDiagnosis: one(primaryDiagnoses, {
    fields: [patients.primaryDiagnosisId],
    references: [primaryDiagnoses.id],
  }),
  patientPharmacy: one(patientPharmacies, {
    fields: [patients.patientPharmacyId],
    references: [patientPharmacies.id],
  }),
  dnrStatus: one(dnr, {
    fields: [patients.dnrId],
    references: [dnr.id],
  }),
  raceEthnicityInfo: one(raceEthnicity, {
    fields: [patients.raceEthnicityId],
    references: [raceEthnicity.id],
  }),
  emergencyPreparedness: one(emergencyPreparednessLevel, {
    fields: [patients.emergencyPreparednessLevelId],
    references: [emergencyPreparednessLevel.id],
  }),
  liaisonPrimaryContact: one(liaisonPrimary, {
    fields: [patients.liaisonPrimaryId],
    references: [liaisonPrimary.id],
  }),
  liaisonSecondaryContact: one(liaisonSecondary, {
    fields: [patients.liaisonSecondaryId],
    references: [liaisonSecondary.id],
  }),
  benefitPeriods: many(benefitPeriods),
  identifiers: many(patientIdentifiers),
  painAssessments: many(painAssessments),
}));
