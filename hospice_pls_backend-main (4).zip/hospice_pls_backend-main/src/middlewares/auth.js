// JWT authentication middleware for protected routes
export const authMiddleware = async (request, reply) => {
  try {
    // Verify JWT token
    await request.jwtVerify();
  } catch (err) {
    reply.code(401).send({
      error: 'Unauthorized',
      message: 'Invalid or missing token'
    });
  }
};
