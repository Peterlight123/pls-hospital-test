import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import jwt from '@fastify/jwt';
import 'dotenv/config';
import { closeDatabase } from './src/config/database.js';

// Import routes
import authRoutes from './src/routes/auth.js';
import patientRoutes from './src/routes/patients.js';

// Create Fastify instance with logging
const fastify = Fastify({
  logger: {
    transport: {
      target: 'pino-pretty',
      options: {
        translateTime: 'HH:MM:ss Z',
        ignore: 'pid,hostname',
        colorize: true,
      },
    },
  },
});

// Register plugins
await fastify.register(cors, {
  origin: true,
  credentials: true,
});

await fastify.register(helmet, {
  contentSecurityPolicy: false,
});

// Register JWT
await fastify.register(jwt, {
  secret: process.env.JWT_SECRET || 'your-super-secret-jwt-key-change-this-in-production',
});

// Health check route
fastify.get('/ping', async (request, reply) => {
  return { message: 'pong', status: 'ok', timestamp: new Date().toISOString() };
});

// Register API routes
await fastify.register(authRoutes, { prefix: '/api' });
await fastify.register(patientRoutes, { prefix: '/api' });

// Error handler
fastify.setErrorHandler((error, request, reply) => {
  request.log.error(error);

  if (error.validation) {
    return reply.code(400).send({
      error: 'Validation failed',
      details: error.validation,
    });
  }

  const statusCode = error.statusCode || 500;
  return reply.code(statusCode).send({
    error: error.message || 'Internal Server Error',
    statusCode,
  });
});

// Graceful shutdown
const gracefulShutdown = async () => {
  fastify.log.info('Shutting down gracefully...');
  await closeDatabase();
  await fastify.close();
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
const start = async () => {
  try {
    const port = process.env.PORT || 3000;
    const host = process.env.HOST || '0.0.0.0';

    await fastify.listen({ port: parseInt(port), host });
    fastify.log.info(`Server running on ${host}:${port}`);
    fastify.log.info(`Health check: http://${host}:${port}/ping`);
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
};

start();
