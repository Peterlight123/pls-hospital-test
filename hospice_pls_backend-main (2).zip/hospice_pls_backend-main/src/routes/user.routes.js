// src/routes/user.routes.js

import { z } from 'zod';
import * as userController from '../controllers/user.controller.js';

// --- ZOD SCHEMAS for Validation ---

// Schema for creating a new user (POST /users)
const createUserBodySchema = z.object({
    first_name: z.string().min(2).max(255),
    last_name: z.string().min(2).max(255),
    email: z.string().email(),
    password: z.string().min(8, 'Password must be at least 8 characters long'),
    contact: z.string().optional(),
    // Role is optional on creation, defaults to 'user' in controller
    role: z.enum(['admin', 'moderator', 'user']).optional(), 
    // Avatar is handled via multipart, not validated in the body schema
});

// Schema for updating an existing user (PUT /users/:id)
const updateUserBodySchema = z.object({
    first_name: z.string().min(2).max(255).optional(),
    last_name: z.string().min(2).max(255).optional(),
    email: z.string().email().optional(),
    // Password is optional for updates
    password: z.string().min(8, 'Password must be at least 8 characters long').optional(), 
    contact: z.string().optional(),
    role: z.enum(['admin', 'moderator', 'user']).optional(),
    // If all fields are optional, ensure at least one is present (optional check for realism)
}).refine(data => Object.keys(data).length > 0, {
    message: "Request body must contain at least one field to update.",
});

// Schema for ID parameter validation (GET/PUT/DELETE /users/:id)
const userIdParamsSchema = z.object({
    // ID must be a number string which Fastify will cast to a string, validated as a numeric string
    id: z.string().regex(/^\d+$/, 'ID must be a numeric string').transform(Number),
});

// Validation helper function
function validateWithZod(schema, target = 'body') {
    return async (request, reply) => {
        try {
            const data = target === 'params' ? request.params : request.body;
            const result = schema.safeParse(data);
            if (!result.success) {
                return reply.code(400).send({
                    statusCode: 400,
                    error: 'Bad Request',
                    message: 'Validation failed',
                    details: result.error.issues
                });
            }
            // Replace the original data with validated/transformed data
            if (target === 'params') {
                request.params = result.data;
            } else {
                request.body = result.data;
            }
        } catch (error) {
            return reply.code(400).send({
                statusCode: 400,
                error: 'Bad Request',
                message: 'Validation error',
                details: error.message
            });
        }
    };
}

/**
 * The Fastify route plugin function for the User module.
 * @param {objec} fastify - The Fastiy instance.
 * @param {object} options - Plugin options.
 */
async function userRoutes(fastify, options) {
    // --- GET /users (index) ---
    // Fetches all users with their roles. No request body/params validation needed.
    fastify.get('/', {
        // Pre-handler for authorization/authentication would go here if needed.
    }, userController.index);

    // --- POST /users (store) ---
    // Creates a new user. Requires validation for the body (createUserBodySchema).
    fastify.post('/', {
        preValidation: validateWithZod(createUserBodySchema)
    }, userController.store);

    // --- GET /users/:id (show) ---
    // Retrieves a single user. Requires validation for the ID parameter.
    fastify.get('/:id', {
        preValidation: validateWithZod(userIdParamsSchema, 'params')
    }, userController.show);

    // --- PUT /users/:id (update) ---
    // Updates an existing user. Requires validation for both ID parameter and the body.
    fastify.put('/:id', {
        preValidation: [validateWithZod(userIdParamsSchema, 'params'), validateWithZod(updateUserBodySchema, 'body')]
    }, userController.update);

    // --- DELETE /users/:id (destroy) ---
    // Deletes a user. Requires validation for the ID parameter.
    fastify.delete('/:id', {
        preValidation: validateWithZod(userIdParamsSchema, 'params')
    }, userController.destroy);
}

// Export the function as a default Fastify plugin
export default userRoutes;
