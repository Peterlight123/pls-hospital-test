// src/models/schema.js

import { pgTable, serial, integer, text, varchar, timestamp, uniqueIndex, pgEnum, boolean, primaryKey } from 'drizzle-orm/pg-core';
import { relations } from 'drizzle-orm';

/**
 * Define the Roles enum for known roles, matching the Laravel logic (e.g., 'admin', 'user').
 * Drizzle ORM requires explicit type definitions for enums.
 */
export const userRoleEnum = pgEnum('user_role', ['admin', 'moderator', 'user', 'guest']);

// --- Users Table Definition ---
// This table mirrors the User model from Laravel.
export const users = pgTable('users', {
    // Primary key: auto-incrementing integer ID
    id: serial('id').primaryKey(),
    // User's first name
    first_name: varchar('first_name', { length: 256 }).notNull(),
    // User's last name
    last_name: varchar('last_name', { length: 256 }).notNull(),
    // Unique email address (used for login and identification)
    email: varchar('email', { length: 256 }).notNull().unique(),
    // Hashed password (will be managed by bcrypt, replacing Laravel's Hash::make)
    password: text('password').notNull(),
    // Contact information (e.g., phone number)
    contact: varchar('contact', { length: 50 }),
    // Avatar file name (stored path)
    avatar: varchar('avatar', { length: 256 }),
    // Timestamp for creation
    created_at: timestamp('created_at').defaultNow().notNull(),
    // Timestamp for last update
    updated_at: timestamp('updated_at').defaultNow().notNull(),
});

// --- Roles Table Definition ---
// This mimics the 'roles' table used by Spatie's permission package.
export const roles = pgTable('roles', {
    // Primary key
    id: serial('id').primaryKey(),
    // Unique name of the role (e.g., 'admin')
    name: varchar('name', { length: 50 }).notNull().unique(),
    // Timestamp for creation
    created_at: timestamp('created_at').defaultNow().notNull(),
});

// --- Users to Roles Join Table Definition ---
// This many-to-many junction table links Users and Roles.
export const usersToRoles = pgTable('users_to_roles', {
        user_id: integer('user_id')
            .notNull()
            .references(() => users.id, { onDelete: 'cascade' }), // Foreign key to users
        role_id: integer('role_id')
            .notNull()
            .references(() => roles.id, { onDelete: 'cascade' }), // Foreign key to roles
    }, (t) => ({
        // Compound primary key ensures a user can only have one instance of a role
        pk: primaryKey({ columns: [t.user_id, t.role_id] }),
    })
);

// --- Drizzle Relations ---
// Defines how the tables are connected for joins (eager loading in Laravel terms).
export const usersRelations = relations(users, ({ many }) => ({
    // A User can have many roles via the usersToRoles join table
    usersToRoles: many(usersToRoles),
}));

export const rolesRelations = relations(roles, ({ many }) => ({
    // A Role can be assigned to many users via the usersToRoles join table
    usersToRoles: many(usersToRoles),
}));

export const usersToRolesRelations = relations(usersToRoles, ({ one }) => ({
    // Each record links back to one User
    user: one(users, {
        fields: [usersToRoles.user_id],
        references: [users.id],
    }),
    // Each record links back to one Role
    role: one(roles, {
        fields: [usersToRoles.role_id],
        references: [roles.id],
    }),
}));
