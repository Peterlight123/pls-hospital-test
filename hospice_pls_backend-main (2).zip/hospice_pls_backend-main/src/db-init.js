// src/db-init.js
// Database initialization script to create tables and seed initial data

import { db } from './models/db.js';
import { users, roles, usersToRoles } from './models/schema.js';
import { sql } from 'drizzle-orm';

async function initializeDatabase() {
    try {
        console.log('Starting database initialization...');

        // Create the user_role enum type if it doesn't exist
        await db.execute(sql`
            DO $$ BEGIN
                CREATE TYPE user_role AS ENUM ('admin', 'moderator', 'user', 'guest');
            EXCEPTION
                WHEN duplicate_object THEN null;
            END $$;
        `);
        console.log('✓ Enum type created/verified');

        // Create roles table
        await db.execute(sql`
            CREATE TABLE IF NOT EXISTS roles (
                id SERIAL PRIMARY KEY,
                name VARCHAR(50) NOT NULL UNIQUE,
                created_at TIMESTAMP DEFAULT NOW() NOT NULL
            );
        `);
        console.log('✓ Roles table created');

        // Create users table
        await db.execute(sql`
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                first_name VARCHAR(256) NOT NULL,
                last_name VARCHAR(256) NOT NULL,
                email VARCHAR(256) NOT NULL UNIQUE,
                password TEXT NOT NULL,
                contact VARCHAR(50),
                avatar VARCHAR(256),
                created_at TIMESTAMP DEFAULT NOW() NOT NULL,
                updated_at TIMESTAMP DEFAULT NOW() NOT NULL
            );
        `);
        console.log('✓ Users table created');

        // Create users_to_roles junction table
        await db.execute(sql`
            CREATE TABLE IF NOT EXISTS users_to_roles (
                user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                role_id INTEGER NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
                PRIMARY KEY (user_id, role_id)
            );
        `);
        console.log('✓ Users-to-Roles junction table created');

        // Seed roles if they don't exist
        const existingRoles = await db.select().from(roles);
        
        if (existingRoles.length === 0) {
            console.log('Seeding roles...');
            await db.insert(roles).values([
                { name: 'admin' },
                { name: 'moderator' },
                { name: 'user' },
                { name: 'guest' }
            ]);
            console.log('✓ Roles seeded successfully');
        } else {
            console.log('✓ Roles already exist, skipping seed');
        }

        console.log('\n✅ Database initialization completed successfully!');
        console.log('The following tables are ready:');
        console.log('  - users');
        console.log('  - roles');
        console.log('  - users_to_roles');
        
        process.exit(0);
    } catch (error) {
        console.error('❌ Database initialization failed:', error);
        process.exit(1);
    }
}

initializeDatabase();
